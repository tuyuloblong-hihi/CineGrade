# CineGrade (fase 1, langkah 1-4 + 6, multi-klip)

Kerangka aplikasi + impor klip + pemutar dengan efek LUT `.cube`, slider intensitas, ekspor ke galeri (Movies/CineGrade), dan deteksi shot dengan timeline thumbnail, dan proyek multi-klip (impor banyak klip, urutkan, hapus, ekspor gabungan atau per klip), dan penyeragaman exposure/warna antar-klip.

## Cara menjalankan
1. Buka folder ini di **Android Studio** (versi terbaru), tunggu Gradle sync.
   Bila diminta, izinkan pembaruan AGP/Kotlin atau versi Media3 ke yang terbaru.
2. Hubungkan Poco F4 GT (USB debugging aktif), lalu Run.
3. Salin `sample_teal_orange.cube` ke HP (misalnya folder Download).
4. Di aplikasi: **Pilih klip** (Photo Picker), lalu **Pilih LUT .cube**.
   Geser slider intensitas dan lepaskan untuk menerapkan.

## Uji unit
`./gradlew test` menjalankan CubeLutTest (parser .cube: urutan data, DOMAIN, error).

## Struktur
- `look/CubeLut.kt`    parser LUT 3D, murni Kotlin
- `gl/LutEffect.kt`    LUT -> efek Media3 (intensitas dipanggang ke LUT)
- `media/VideoInfo.kt` metadata klip (resolusi, fps, rotasi, info warna)
- `shot/ShotSegmenter.kt` memotong klip jadi shot dari jarak antar-frame (murni Kotlin, ada unit test)
- `shot/ShotAnalyzer.kt`  sampel frame + histogram warna + thumbnail
- `match/ClipMatcher.kt` statistik klip, koreksi penyeragaman, pembuat LUT gabungan (koreksi + look)
- `media/Exporter.kt`  ekspor Media3 Transformer + simpan ke MediaStore
- `ui/GradeScreen.kt`  layar utama Compose

## Batasan saat ini (sengaja, untuk langkah berikutnya)
- Efek LUT bawaan Media3 memakai 8-bit; langkah 3 menggantinya dengan shader RGBA16F + dither.
- Ekspor berjalan di layar aplikasi (layar dijaga menyala); foreground service untuk klip panjang menyusul di langkah 5.
- Ekspor gabungan: klip yang ukuran tampilannya beda dari klip pertama dimasukkan ke bingkai klip pertama (ada letterbox). Paling aman untuk klip dengan pengaturan rekam yang sama.
- Penyeragaman bekerja per klip (bukan per shot) dan menyamakan kecerahan rata-rata: adegan yang memang sengaja gelap ikut dicerahkan, jadi kurangi kekuatannya bila perlu. Preview memutar satu klip pada satu waktu (efek dipasang sebelum klip dimuat) dan otomatis lanjut ke klip berikutnya, dengan jeda singkat di antara klip.
- Timeline shot baru menampilkan dan memilih shot; LUT per shot (preview dan ekspor) menyusul bersama shader sendiri.
- Belum ada profil look dari foto referensi atau AI.
- Belum dikompilasi di lingkungan pembuatnya: kemungkinan perlu penyesuaian kecil versi/API.
