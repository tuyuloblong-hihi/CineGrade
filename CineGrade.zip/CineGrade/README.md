# CineGrade (fase 1, langkah 1-4)

Kerangka aplikasi + impor klip + pemutar dengan efek LUT `.cube`, slider intensitas, dan ekspor ke galeri (Movies/CineGrade).

## Cara menjalankan
1. Buka folder ini di **Android Studio** (versi terbaru), tunggu Gradle sync.
   Bila diminta, izinkan pembaruan AGP/Kotlin atau versi Media3 ke yang terbaru.
2. Hubungkan Poco F4 GT (USB debugging aktif), lalu Run.
3. Salin `sample_teal_orange.cube` ke HP (misalnya folder Download).
4. Di aplikasi: **Pilih klip** (Photo Picker), lalu **Pilih LUT .cube**.
   Geser slider intensitas dan lepaskan untuk menerapkan.

## Uji unit
`./gradlew test` menjalankan CubeLutTest (parser .cube: urutan data, DOMAIN, error).

## Struktur
- `look/CubeLut.kt`    parser LUT 3D, murni Kotlin
- `gl/LutEffect.kt`    LUT -> efek Media3 (intensitas dipanggang ke LUT)
- `media/VideoInfo.kt` metadata klip (resolusi, fps, rotasi, info warna)
- `media/Exporter.kt`  ekspor Media3 Transformer + simpan ke MediaStore
- `ui/GradeScreen.kt`  layar utama Compose

## Batasan saat ini (sengaja, untuk langkah berikutnya)
- Efek LUT bawaan Media3 memakai 8-bit; langkah 3 menggantinya dengan shader RGBA16F + dither.
- Ekspor berjalan di layar aplikasi (layar dijaga menyala); foreground service untuk klip panjang menyusul di langkah 5.
- Belum ada shot timeline atau AI.
- Belum dikompilasi di lingkungan pembuatnya: kemungkinan perlu penyesuaian kecil versi/API.
