package com.example.cinegrade.shot

data class Shot(val startMs: Long, val endMs: Long) {
    val durationMs: Long get() = endMs - startMs
}

/**
 * Memotong klip menjadi shot dari jarak antar-frame sampel. Murni Kotlin (mudah diuji).
 *
 * times[i]     : waktu frame sampel ke-i (ms), menaik
 * distances[i] : jarak histogram frame i terhadap frame i-1 (0..1); distances[0] diabaikan
 * threshold    : jarak minimum agar dianggap pergantian shot
 * minShotMs    : shot lebih pendek dari ini tidak dibuat (menahan false cut akibat kedipan exposure)
 */
object ShotSegmenter {
    fun segment(
        times: LongArray,
        distances: FloatArray,
        durationMs: Long,
        threshold: Float,
        minShotMs: Long = 800,
    ): List<Shot> {
        require(times.size == distances.size) { "times dan distances harus sama panjang" }
        val starts = ArrayList<Long>()
        starts.add(0L)
        for (i in 1 until times.size) {
            if (distances[i] >= threshold && times[i] - starts.last() >= minShotMs) {
                starts.add(times[i])
            }
        }
        val end = maxOf(durationMs, starts.last())
        return starts.mapIndexed { idx, s ->
            Shot(s, if (idx + 1 < starts.size) starts[idx + 1] else end)
        }
    }
}
