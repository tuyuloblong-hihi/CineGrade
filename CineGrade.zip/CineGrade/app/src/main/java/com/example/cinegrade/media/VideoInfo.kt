package com.example.cinegrade.media

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build

data class VideoInfo(
    val width: Int,
    val height: Int,
    val rotation: Int,
    val durationMs: Long,
    val fps: Float?,
    val bitrate: Long?,
    val colorStandard: String?,
    val colorTransfer: String?,
    val colorRange: String?,
) {
    /** Ukuran seperti yang terlihat di layar (memperhitungkan rotasi). */
    val displayWidth: Int get() = if (rotation == 90 || rotation == 270) height else width
    val displayHeight: Int get() = if (rotation == 90 || rotation == 270) width else height

    /** Rasio lebar/tinggi seperti yang terlihat di layar (memperhitungkan rotasi). */
    val displayAspect: Float
        get() {
            if (width <= 0 || height <= 0) return 16f / 9f
            return if (rotation == 90 || rotation == 270) height.toFloat() / width else width.toFloat() / height
        }

    fun summary(): String = buildString {
        val (w, h) = if (rotation == 90 || rotation == 270) height to width else width to height
        append("${w}x$h")
        fps?.let { append(" • %.1f fps".format(it)) }
        append(" • %.1f dtk".format(durationMs / 1000f))
        bitrate?.let { append(" • %.1f Mbps".format(it / 1_000_000f)) }
        if (rotation != 0) append(" • rotasi $rotation°")
        colorStandard?.let { append("\nWarna: $it") }
        colorTransfer?.let { append(" / $it") }
        colorRange?.let { append(" / $it") }
    }

    companion object {
        fun read(context: Context, uri: Uri): VideoInfo {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, uri)
                fun s(key: Int) = r.extractMetadata(key)
                val duration = s(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val frames = s(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toLongOrNull()
                val fps = s(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()
                    ?: if (frames != null && duration > 0) frames * 1000f / duration else null

                var std: String? = null
                var transfer: String? = null
                var range: String? = null
                if (Build.VERSION.SDK_INT >= 33) {
                    std = when (s(MediaMetadataRetriever.METADATA_KEY_COLOR_STANDARD)?.toIntOrNull()) {
                        1 -> "BT.709"
                        2 -> "BT.601 (625)"
                        4 -> "BT.601 (525)"
                        6 -> "BT.2020"
                        null -> null
                        else -> "lainnya"
                    }
                    transfer = when (s(MediaMetadataRetriever.METADATA_KEY_COLOR_TRANSFER)?.toIntOrNull()) {
                        3 -> "SDR"
                        6 -> "PQ"
                        7 -> "HLG"
                        1 -> "Linear"
                        null -> null
                        else -> "lainnya"
                    }
                    range = when (s(MediaMetadataRetriever.METADATA_KEY_COLOR_RANGE)?.toIntOrNull()) {
                        1 -> "full"
                        2 -> "limited"
                        null -> null
                        else -> "lainnya"
                    }
                }
                return VideoInfo(
                    width = s(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0,
                    height = s(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0,
                    rotation = s(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0,
                    durationMs = duration,
                    fps = fps,
                    bitrate = s(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull(),
                    colorStandard = std,
                    colorTransfer = transfer,
                    colorRange = range,
                )
            } finally {
                r.release()
            }
        }
    }
}
