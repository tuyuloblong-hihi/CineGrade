package com.example.cinegrade.match

import com.example.cinegrade.look.CubeLut
import kotlin.math.ln
import kotlin.math.log2
import kotlin.math.pow

/**
 * Statistik satu klip dari frame sampel, semua dalam ruang gamma 0..1 (seperti nilai piksel video).
 * p5/p50/p95 = persentil luma; mean = rata-rata kanal; meanSat = rata-rata saturasi (max-min)/max.
 */
data class ClipStats(
    val p5: Float,
    val p50: Float,
    val p95: Float,
    val meanR: Float,
    val meanG: Float,
    val meanB: Float,
    val meanSat: Float,
) {
    companion object {
        fun average(list: List<ClipStats>): ClipStats {
            require(list.isNotEmpty()) { "Daftar statistik kosong" }
            fun avg(f: (ClipStats) -> Float) = list.map(f).average().toFloat()
            return ClipStats(
                avg { it.p5 }, avg { it.p50 }, avg { it.p95 },
                avg { it.meanR }, avg { it.meanG }, avg { it.meanB },
                avg { it.meanSat },
            )
        }
    }
}

/**
 * Koreksi penyeragaman untuk satu klip: exposure (gain di ruang linear), white balance ringan,
 * kontras di sekitar titik tengah, dan saturasi. Semua parameter sudah dikalikan kekuatan.
 */
data class Correction(
    val gain: Float,
    val wbR: Float,
    val wbB: Float,
    val contrast: Float,
    val saturation: Float,
    val pivot: Float,
) {
    /** Perubahan exposure dalam stop (EV). */
    val evStops: Float get() = ln(gain) / ln(2f)

    /** Menerapkan koreksi pada satu piksel (gamma 0..1). Hasil ditulis ke out[0..2]. */
    fun apply(r: Float, g: Float, b: Float, out: FloatArray) {
        val inv = 1f / ClipMatcher.GAMMA
        fun ex(v: Float): Float =
            (v.coerceIn(0f, 1f).pow(ClipMatcher.GAMMA) * gain).pow(inv).coerceIn(0f, 1f)

        var rr = ex(r) * wbR
        var gg = ex(g)
        var bb = ex(b) * wbB

        rr = pivot + (rr - pivot) * contrast
        gg = pivot + (gg - pivot) * contrast
        bb = pivot + (bb - pivot) * contrast

        val y = 0.2126f * rr + 0.7152f * gg + 0.0722f * bb
        rr = y + (rr - y) * saturation
        gg = y + (gg - y) * saturation
        bb = y + (bb - y) * saturation

        out[0] = rr.coerceIn(0f, 1f)
        out[1] = gg.coerceIn(0f, 1f)
        out[2] = bb.coerceIn(0f, 1f)
    }
}

object ClipMatcher {
    const val GAMMA = 2.2f
    private const val MAX_STOPS = 1.5f

    /** Menghitung koreksi agar statistik [src] mendekati [tgt]. strength 0..1. */
    fun correction(src: ClipStats, tgt: ClipStats, strength: Float): Correction {
        val k = strength.coerceIn(0f, 1f)

        // Exposure: samakan median. Gain di ruang linear = (tm/sm)^GAMMA, dibatasi +-1,5 stop.
        val sm = src.p50.coerceAtLeast(0.02f)
        val tm = tgt.p50.coerceAtLeast(0.02f)
        val stops = (GAMMA * log2(tm / sm)).coerceIn(-MAX_STOPS, MAX_STOPS) * k
        val gain = 2f.pow(stops)

        // Kontras: samakan sebaran p5..p95, dibatasi 0,8x..1,25x.
        val sSpread = (src.p95 - src.p5).coerceAtLeast(0.05f)
        val tSpread = (tgt.p95 - tgt.p5).coerceAtLeast(0.05f)
        val contrast = 1f + ((tSpread / sSpread).coerceIn(0.8f, 1.25f) - 1f) * k

        // White balance ringan (gray-world), dibatasi +-8% supaya warna alami adegan tidak rusak.
        val sG = src.meanG.coerceAtLeast(0.01f)
        val tG = tgt.meanG.coerceAtLeast(0.01f)
        val wbRaw = { s: Float, t: Float ->
            ((t / tG) / (s.coerceAtLeast(0.01f) / sG)).coerceIn(0.92f, 1.08f)
        }
        val wbR = 1f + (wbRaw(src.meanR, tgt.meanR) - 1f) * k
        val wbB = 1f + (wbRaw(src.meanB, tgt.meanB) - 1f) * k

        // Saturasi: dibatasi 0,8x..1,25x.
        val sat = 1f + ((tgt.meanSat / src.meanSat.coerceAtLeast(0.02f)).coerceIn(0.8f, 1.25f) - 1f) * k

        // Titik tengah kontras = median sumber setelah exposure.
        val pivot = (src.p50.coerceIn(0f, 1f).pow(GAMMA) * gain).pow(1f / GAMMA).coerceIn(0f, 1f)

        return Correction(gain, wbR, wbB, contrast, sat, pivot)
    }
}

/** Membuat LUT 3D gabungan: koreksi penyeragaman dulu, lalu look kreatif (opsional). */
object ClipLutBuilder {
    fun build(
        creative: CubeLut?,
        lookStrength: Float,
        correction: Correction?,
        size: Int = 33,
    ): CubeLut {
        val k = lookStrength.coerceIn(0f, 1f)
        val last = (size - 1).toFloat()
        val data = FloatArray(size * size * size * 3)
        val tmp = FloatArray(3)
        val look = FloatArray(3)
        for (b in 0 until size) for (g in 0 until size) for (r in 0 until size) {
            var cr = r / last
            var cg = g / last
            var cb = b / last
            if (correction != null) {
                correction.apply(cr, cg, cb, tmp)
                cr = tmp[0]; cg = tmp[1]; cb = tmp[2]
            }
            var outR = cr
            var outG = cg
            var outB = cb
            if (creative != null) {
                creative.sample(cr, cg, cb, look)
                outR = cr + (look[0] - cr) * k
                outG = cg + (look[1] - cg) * k
                outB = cb + (look[2] - cb) * k
            }
            val i = ((b * size + g) * size + r) * 3
            data[i] = outR.coerceIn(0f, 1f)
            data[i + 1] = outG.coerceIn(0f, 1f)
            data[i + 2] = outB.coerceIn(0f, 1f)
        }
        return CubeLut(size, data)
    }
}
