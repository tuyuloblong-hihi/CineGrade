package com.example.cinegrade.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.cinegrade.gl.buildLutEffect
import com.example.cinegrade.look.CubeLut
import com.example.cinegrade.match.ClipLutBuilder
import com.example.cinegrade.match.ClipMatcher
import com.example.cinegrade.match.ClipStats
import com.example.cinegrade.match.Correction
import com.example.cinegrade.media.ExportClip
import com.example.cinegrade.media.Exporter
import com.example.cinegrade.media.VideoInfo
import com.example.cinegrade.shot.ShotAnalyzer
import com.example.cinegrade.shot.ShotSegmenter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class ClipItem(val uri: Uri, val info: VideoInfo)

private fun fmtTime(ms: Long): String {
    val totalSec = ms / 1000f
    val m = (totalSec / 60).toInt()
    val s = totalSec - m * 60
    return "%d:%04.1f".format(m, s)
}

@OptIn(UnstableApi::class)
@Composable
fun GradeScreen() {
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    // ---- Proyek: daftar klip ----
    val clips = remember { mutableStateListOf<ClipItem>() }
    var selectedClip by remember { mutableIntStateOf(0) }
    val selected = clips.getOrNull(selectedClip)
    val selectedKey = selected?.uri?.toString()

    var lut by remember { mutableStateOf<CubeLut?>(null) }
    var lutName by remember { mutableStateOf<String?>(null) }
    var strength by remember { mutableFloatStateOf(1f) }
    var message by remember { mutableStateOf<String?>(null) }   // galat
    var status by remember { mutableStateOf<String?>(null) }    // info biasa

    // ---- Ekspor ----
    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var exportLabel by remember { mutableStateOf<String?>(null) }
    var exportJob by remember { mutableStateOf<Job?>(null) }
    var combine by remember { mutableStateOf(true) }

    // ---- Penyeragaman antar-klip ----
    var equalize by remember { mutableStateOf(false) }
    var equalizeStrength by remember { mutableFloatStateOf(0.8f) }
    var targetKey by remember { mutableStateOf<String?>(null) }   // null = rata-rata semua klip

    // ---- Analisis shot (per klip, berurutan) ----
    val analyses = remember { mutableStateMapOf<String, ShotAnalyzer.Result>() }
    val analysisMutex = remember { Mutex() }
    var analyzingKey by remember { mutableStateOf<String?>(null) }
    var analysisProgress by remember { mutableIntStateOf(0) }
    var thresholdUi by remember { mutableFloatStateOf(0.40f) }   // posisi slider
    var threshold by remember { mutableFloatStateOf(0.40f) }     // nilai yang dipakai (saat slider dilepas)
    var selectedShot by remember { mutableIntStateOf(0) }
    val thumbs = remember { mutableStateMapOf<String, ImageBitmap>() }       // "uri|startMs"
    val clipThumbs = remember { mutableStateMapOf<String, ImageBitmap>() }   // "uri"

    val analysis = selectedKey?.let { analyses[it] }
    val shots = remember(analysis, threshold) {
        analysis?.let { ShotSegmenter.segment(it.times, it.distances, it.durationMs, threshold) }
            ?: emptyList()
    }

    fun correctionFor(clip: ClipItem): Correction? {
        if (!equalize) return null
        val own: ClipStats = analyses[clip.uri.toString()]?.stats ?: return null
        val all = clips.mapNotNull { analyses[it.uri.toString()]?.stats }
        val target: ClipStats = targetKey?.let { analyses[it]?.stats }
            ?: if (all.size >= 2) ClipStats.average(all) else return null
        return ClipMatcher.correction(own, target, equalizeStrength)
    }

    fun effectFor(clip: ClipItem): Effect? {
        val c = correctionFor(clip)
        val l = lut
        if (l == null && c == null) return null
        return buildLutEffect(ClipLutBuilder.build(l, strength, c), 1f)
    }

    // Pemutar hanya memegang satu klip pada satu waktu. Efek dipasang sebelum prepare(),
    // jadi pipeline tidak dikonfigurasi ulang saat video berjalan (menghindari kedipan/macet).
    fun loadClip(index: Int, startMs: Long, play: Boolean) {
        val clip = clips.getOrNull(index) ?: return
        player.stop()
        val e = effectFor(clip)
        player.setVideoEffects(if (e == null) emptyList() else listOf(e))
        player.setMediaItem(MediaItem.fromUri(clip.uri), startMs)
        player.prepare()
        player.playWhenReady = play
    }

    // Muat ulang klip yang sedang tampil (posisi dipertahankan) setelah pengaturan grading berubah.
    fun refreshPreview() {
        if (clips.isEmpty() || player.mediaItemCount == 0) return
        val ended = player.playbackState == Player.STATE_ENDED
        loadClip(
            selectedClip,
            if (ended) 0L else player.currentPosition,
            !ended && player.playWhenReady,
        )
    }

    // Otomatis lanjut ke klip berikutnya saat klip selesai diputar.
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    val next = selectedClip + 1
                    if (next in clips.indices) {
                        selectedClip = next
                        selectedShot = 0
                        view.post { loadClip(next, 0L, true) }
                    }
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // Thumbnail shot untuk klip terpilih
    LaunchedEffect(shots, selectedKey) {
        val clip = selected ?: return@LaunchedEffect
        val key = clip.uri.toString()
        val h = 144
        val w = (h * clip.info.displayAspect).toInt().coerceIn(64, 320)
        for (s in shots) {
            val k = "$key|${s.startMs}"
            if (thumbs.containsKey(k)) continue
            val at = s.startMs + minOf(300L, s.durationMs / 2)
            val bmp = ShotAnalyzer.thumbnail(context, clip.uri, at, w, h)
            if (bmp != null) thumbs[k] = bmp.asImageBitmap()
        }
    }

    // Layar tetap menyala selama ekspor (foreground service menyusul di langkah berikutnya).
    DisposableEffect(exporting) {
        view.keepScreenOn = exporting
        onDispose { view.keepScreenOn = false }
    }

    suspend fun prepareClip(item: ClipItem) {
        val key = item.uri.toString()
        val h = 120
        val w = (h * item.info.displayAspect).toInt().coerceIn(64, 320)
        ShotAnalyzer.thumbnail(context, item.uri, 0L, w, h)?.let { clipThumbs[key] = it.asImageBitmap() }
        analysisMutex.withLock {
            analyzingKey = key
            analysisProgress = 0
            try {
                analyses[key] = ShotAnalyzer.analyze(context, item.uri, item.info.durationMs) {
                    analysisProgress = it
                }
                if (equalize) refreshPreview()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "Analisis shot gagal: ${e.message}"
            } finally {
                analyzingKey = null
            }
        }
    }

    fun removeSelected() {
        val i = selectedClip
        if (i !in clips.indices) return
        val removed = clips.removeAt(i)
        val key = removed.uri.toString()
        analyses.remove(key)
        if (targetKey == key) targetKey = null
        clipThumbs.remove(key)
        thumbs.keys.filter { it.startsWith("$key|") }.forEach { thumbs.remove(it) }
        selectedClip = selectedClip.coerceAtMost(clips.lastIndex).coerceAtLeast(0)
        selectedShot = 0
        if (clips.isEmpty()) {
            player.stop()
            player.clearMediaItems()
        } else {
            loadClip(selectedClip, 0L, false)
        }
    }

    fun moveSelected(delta: Int) {
        val from = selectedClip
        val to = from + delta
        if (from !in clips.indices || to !in clips.indices) return
        clips.add(to, clips.removeAt(from))
        selectedClip = to
    }

    fun startExport() {
        val snapshot = clips.toList()
        if (snapshot.isEmpty()) return
        if (lut == null && !equalize) return
        val effects: List<Effect?> = snapshot.map { effectFor(it) }
        player.pause()
        exporting = true
        progress = 0
        message = null
        status = null
        exportLabel = null
        exportJob = scope.launch {
            var saved = 0
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                if (combine && snapshot.size > 1) {
                    exportLabel = "Menggabungkan ${snapshot.size} klip"
                    val file = Exporter.exportCombined(
                        context = context,
                        clips = snapshot.mapIndexed { idx, it ->
                            ExportClip(
                                it.uri,
                                it.info.displayWidth,
                                it.info.displayHeight,
                                it.info.bitrate,
                                effects[idx],
                            )
                        },
                        onProgress = { progress = it },
                    )
                    val name = "CineGrade_${stamp}_gabungan.mp4"
                    withContext(Dispatchers.IO) {
                        Exporter.saveToGallery(context, file, name)
                        file.delete()
                    }
                    saved = 1
                    status = "Selesai. Tersimpan di Movies/CineGrade/$name"
                } else {
                    val n = snapshot.size
                    for ((i, c) in snapshot.withIndex()) {
                        exportLabel = "Klip ${i + 1} dari $n"
                        val file = Exporter.exportSingle(
                            context = context,
                            source = c.uri,
                            videoEffect = effects[i],
                            sourceBitrate = c.info.bitrate,
                            onProgress = { p -> progress = (i * 100 + p) / n },
                        )
                        val name = if (n == 1) "CineGrade_$stamp.mp4" else "CineGrade_${stamp}_${i + 1}.mp4"
                        withContext(Dispatchers.IO) {
                            Exporter.saveToGallery(context, file, name)
                            file.delete()
                        }
                        saved++
                    }
                    status = "Selesai. $saved file tersimpan di Movies/CineGrade"
                }
            } catch (e: CancellationException) {
                status = "Ekspor dibatalkan." + if (saved > 0) " ($saved file sudah tersimpan)" else ""
                throw e
            } catch (e: Exception) {
                message = "Ekspor gagal: ${e.message}" + if (saved > 0) " ($saved file sudah tersimpan)" else ""
            } finally {
                exporting = false
                exportLabel = null
            }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(10)
    ) { uris: List<Uri> ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            val wasEmpty = clips.isEmpty()
            val added = ArrayList<ClipItem>()
            for (uri in uris) {
                try {
                    val info = withContext(Dispatchers.IO) { VideoInfo.read(context, uri) }
                    val item = ClipItem(uri, info)
                    clips.add(item)
                    added.add(item)
                } catch (e: Exception) {
                    message = "Gagal membuka klip: ${e.message}"
                }
            }
            if (added.isEmpty()) return@launch
            if (wasEmpty) {
                selectedClip = 0
                selectedShot = 0
                loadClip(0, 0L, true)
            }
            status = null
            if (message?.startsWith("Gagal membuka") == false) message = null
            added.forEach { item -> scope.launch { prepareClip(item) } }
        }
    }

    val lutPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)!!.bufferedReader().use {
                        CubeLut.parse(it.readText())
                    }
                }
                lut = parsed
                lutName = uri.lastPathSegment?.substringAfterLast('/')
                refreshPreview()
                message = null
            } catch (e: Exception) {
                message = "Gagal membaca LUT: ${e.message}"
            }
        }
    }

    val thumbH = 144
    val thumbW = ((selected?.info?.displayAspect ?: (16f / 9f)) * thumbH).toInt().coerceIn(64, 320)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("CineGrade", style = MaterialTheme.typography.headlineSmall)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = !exporting,
                onClick = {
                    videoPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
            ) { Text(if (clips.isEmpty()) "Pilih klip" else "Tambah klip") }
            Button(
                enabled = !exporting,
                onClick = { lutPicker.launch(arrayOf("*/*")) },
            ) { Text("Pilih LUT .cube") }
        }

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
        )

        // ---- Daftar klip ----
        if (clips.isNotEmpty()) {
            Text("Klip (${clips.size})", style = MaterialTheme.typography.titleMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(clips) { index, clip ->
                    val isSel = index == selectedClip
                    val shape = RoundedCornerShape(8.dp)
                    val key = clip.uri.toString()
                    val cw = (120 * clip.info.displayAspect).toInt().coerceIn(64, 320)
                    Column(
                        modifier = Modifier
                            .clip(shape)
                            .border(
                                2.dp,
                                if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape,
                            )
                            .clickable {
                                selectedClip = index
                                selectedShot = 0
                                loadClip(index, 0L, true)
                            }
                            .padding(4.dp),
                    ) {
                        val bmp = clipThumbs[key]
                        if (bmp != null) {
                            Image(
                                bitmap = bmp,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(cw.dp, 120.dp)
                                    .clip(RoundedCornerShape(6.dp)),
                            )
                        } else {
                            Box(Modifier.size(cw.dp, 120.dp))
                        }
                        Text("Klip ${index + 1}", style = MaterialTheme.typography.labelSmall)
                        Text(
                            "%.1f dtk".format(clip.info.durationMs / 1000f),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    enabled = !exporting && selectedClip > 0,
                    onClick = { moveSelected(-1) },
                ) { Text("← Pindah") }
                OutlinedButton(
                    enabled = !exporting && selectedClip < clips.lastIndex,
                    onClick = { moveSelected(1) },
                ) { Text("Pindah →") }
                OutlinedButton(
                    enabled = !exporting,
                    onClick = { removeSelected() },
                ) { Text("Hapus") }
            }
            Text(selected?.let { "Klip ${selectedClip + 1}: " + it.info.summary() } ?: "")
        } else {
            Text("Belum ada klip.")
        }

        Text(lutName?.let { "LUT: $it (${lut?.size}³)" } ?: "Belum ada LUT.")

        Text("Intensitas: ${(strength * 100).toInt()}%")
        Slider(
            value = strength,
            onValueChange = { strength = it },
            onValueChangeFinished = { refreshPreview() },
            valueRange = 0f..1f,
            enabled = !exporting,
        )

        // ---- Timeline shot (klip terpilih) ----
        if (selected != null) {
            Text("Shot pada klip ${selectedClip + 1}", style = MaterialTheme.typography.titleMedium)
            if (analysis == null) {
                if (analyzingKey == selectedKey) {
                    Text("Menganalisis shot… $analysisProgress%")
                    LinearProgressIndicator(
                        progress = { analysisProgress / 100f },
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    Text("Menunggu analisis…")
                }
            } else {
                Text("${shots.size} shot terdeteksi")
                Text(
                    "Ambang perubahan: %.2f (kecil = lebih banyak potongan)".format(thresholdUi),
                    style = MaterialTheme.typography.bodySmall,
                )
                Slider(
                    value = thresholdUi,
                    onValueChange = { thresholdUi = it },
                    onValueChangeFinished = { threshold = thresholdUi; selectedShot = 0 },
                    valueRange = 0.10f..0.80f,
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(shots) { index, shot ->
                        val isSel = index == selectedShot
                        val shape = RoundedCornerShape(8.dp)
                        Column(
                            modifier = Modifier
                                .clip(shape)
                                .border(
                                    2.dp,
                                    if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape,
                                )
                                .clickable {
                                    selectedShot = index
                                    player.seekTo(shot.startMs)
                                }
                                .padding(4.dp),
                        ) {
                            val bmp = thumbs["$selectedKey|${shot.startMs}"]
                            if (bmp != null) {
                                Image(
                                    bitmap = bmp,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(thumbW.dp, thumbH.dp)
                                        .clip(RoundedCornerShape(6.dp)),
                                )
                            } else {
                                Box(Modifier.size(thumbW.dp, thumbH.dp))
                            }
                            Text("#${index + 1}  ${fmtTime(shot.startMs)}", style = MaterialTheme.typography.labelSmall)
                            Text("%.1f dtk".format(shot.durationMs / 1000f), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // ---- Penyeragaman antar-klip ----
        if (clips.size > 1) {
            Text("Penyeragaman antar-klip", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(
                    checked = equalize,
                    onCheckedChange = { equalize = it; refreshPreview() },
                    enabled = !exporting,
                )
                Text(if (equalize) "Aktif" else "Nonaktif")
            }
            if (equalize) {
                val targetIdx = clips.indexOfFirst { it.uri.toString() == targetKey }
                Text(
                    if (targetIdx >= 0) "Target: klip ${targetIdx + 1}" else "Target: rata-rata semua klip",
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = !exporting,
                        onClick = { targetKey = null; refreshPreview() },
                    ) { Text("Rata-rata") }
                    OutlinedButton(
                        enabled = !exporting && selected != null,
                        onClick = { targetKey = selectedKey; refreshPreview() },
                    ) { Text("Jadikan klip ${selectedClip + 1} target") }
                }
                Text("Kekuatan: ${(equalizeStrength * 100).toInt()}%")
                Slider(
                    value = equalizeStrength,
                    onValueChange = { equalizeStrength = it },
                    onValueChangeFinished = { refreshPreview() },
                    valueRange = 0f..1f,
                    enabled = !exporting,
                )
                val corr = selected?.let { correctionFor(it) }
                Text(
                    if (corr != null) {
                        "Klip ${selectedClip + 1}: exposure %+.1f EV • merah ×%.2f • biru ×%.2f • kontras ×%.2f • saturasi ×%.2f"
                            .format(corr.evStops, corr.wbR, corr.wbB, corr.contrast, corr.saturation)
                    } else {
                        "Menunggu analisis semua klip…"
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }

        // ---- Ekspor ----
        if (clips.size > 1 && !exporting) {
            Text("Hasil ekspor", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = combine,
                    onClick = { combine = true },
                    label = { Text("Satu video gabungan") },
                )
                FilterChip(
                    selected = !combine,
                    onClick = { combine = false },
                    label = { Text("Satu file per klip") },
                )
            }
        }

        if (exporting) {
            Text("Mengekspor… $progress%" + (exportLabel?.let { " • $it" } ?: ""))
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(onClick = { exportJob?.cancel() }) { Text("Batalkan") }
        } else {
            Button(
                enabled = clips.isNotEmpty() && (lut != null || equalize),
                onClick = { startExport() },
            ) { Text("Ekspor ke galeri") }
        }

        status?.let { Text(it) }
        message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
