package com.example.cinegrade.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.cinegrade.gl.buildLutEffect
import com.example.cinegrade.look.CubeLut
import com.example.cinegrade.media.Exporter
import com.example.cinegrade.media.VideoInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun GradeScreen() {
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf<VideoInfo?>(null) }
    var lut by remember { mutableStateOf<CubeLut?>(null) }
    var lutName by remember { mutableStateOf<String?>(null) }
    var strength by remember { mutableFloatStateOf(1f) }
    var message by remember { mutableStateOf<String?>(null) }   // galat
    var status by remember { mutableStateOf<String?>(null) }    // info biasa

    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var exportJob by remember { mutableStateOf<Job?>(null) }

    // Layar tetap menyala selama ekspor (foreground service menyusul di langkah 5).
    DisposableEffect(exporting) {
        view.keepScreenOn = exporting
        onDispose { view.keepScreenOn = false }
    }

    // Efek dipasang ulang hanya saat slider dilepas, supaya pipeline tidak berkedip saat digeser.
    fun applyEffects() {
        val l = lut
        player.setVideoEffects(if (l == null) emptyList() else listOf(buildLutEffect(l, strength)))
    }

    fun startExport() {
        val src = videoUri ?: return
        val l = lut ?: return
        player.pause()
        exporting = true
        progress = 0
        message = null
        status = null
        exportJob = scope.launch {
            try {
                val file = Exporter.export(
                    context = context,
                    source = src,
                    videoEffect = buildLutEffect(l, strength),
                    sourceBitrate = info?.bitrate,
                    onProgress = { progress = it },
                )
                val name = "CineGrade_" +
                    SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
                withContext(Dispatchers.IO) {
                    Exporter.saveToGallery(context, file, name)
                    file.delete()
                }
                status = "Selesai. Tersimpan di Movies/CineGrade/$name"
            } catch (e: CancellationException) {
                status = "Ekspor dibatalkan."
                throw e
            } catch (e: Exception) {
                message = "Ekspor gagal: ${e.message}"
            } finally {
                exporting = false
            }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                info = withContext(Dispatchers.IO) { VideoInfo.read(context, uri) }
                videoUri = uri
                player.setMediaItem(MediaItem.fromUri(uri))
                applyEffects()
                player.prepare()
                player.playWhenReady = true
                message = null
                status = null
            } catch (e: Exception) {
                message = "Gagal membuka klip: ${e.message}"
            }
        }
    }

    val lutPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)!!.bufferedReader().use {
                        CubeLut.parse(it.readText())
                    }
                }
                lut = parsed
                lutName = uri.lastPathSegment?.substringAfterLast('/')
                applyEffects()
                message = null
            } catch (e: Exception) {
                message = "Gagal membaca LUT: ${e.message}"
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("CineGrade", style = MaterialTheme.typography.headlineSmall)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = !exporting,
                onClick = {
                    videoPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
            ) { Text("Pilih klip") }
            Button(
                enabled = !exporting,
                onClick = { lutPicker.launch(arrayOf("*/*")) },
            ) { Text("Pilih LUT .cube") }
        }

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
        )

        Text(info?.summary() ?: "Belum ada klip.")
        Text(lutName?.let { "LUT: $it (${lut?.size}³)" } ?: "Belum ada LUT.")

        Text("Intensitas: ${(strength * 100).toInt()}%")
        Slider(
            value = strength,
            onValueChange = { strength = it },
            onValueChangeFinished = { applyEffects() },
            valueRange = 0f..1f,
            enabled = !exporting,
        )

        if (exporting) {
            Text("Mengekspor… $progress%")
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(onClick = { exportJob?.cancel() }) { Text("Batalkan") }
        } else {
            Button(
                enabled = videoUri != null && lut != null,
                onClick = { startExport() },
            ) { Text("Ekspor ke galeri") }
        }

        status?.let { Text(it) }
        message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
