package com.example.cinegrade.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.cinegrade.gl.buildLutEffect
import com.example.cinegrade.look.CubeLut
import com.example.cinegrade.media.VideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(UnstableApi::class)
@Composable
fun GradeScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var info by remember { mutableStateOf<VideoInfo?>(null) }
    var lut by remember { mutableStateOf<CubeLut?>(null) }
    var lutName by remember { mutableStateOf<String?>(null) }
    var strength by remember { mutableFloatStateOf(1f) }
    var message by remember { mutableStateOf<String?>(null) }

    // Efek dipasang ulang hanya saat slider dilepas, supaya pipeline tidak berkedip saat digeser.
    fun applyEffects() {
        val l = lut
        player.setVideoEffects(if (l == null) emptyList() else listOf(buildLutEffect(l, strength)))
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                info = withContext(Dispatchers.IO) { VideoInfo.read(context, uri) }
                player.setMediaItem(MediaItem.fromUri(uri))
                applyEffects()
                player.prepare()
                player.playWhenReady = true
                message = null
            } catch (e: Exception) {
                message = "Gagal membuka klip: ${e.message}"
            }
        }
    }

    val lutPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)!!.bufferedReader().use {
                        CubeLut.parse(it.readText())
                    }
                }
                lut = parsed
                lutName = uri.lastPathSegment?.substringAfterLast('/')
                applyEffects()
                message = null
            } catch (e: Exception) {
                message = "Gagal membaca LUT: ${e.message}"
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("CineGrade", style = MaterialTheme.typography.headlineSmall)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                videoPicker.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                )
            }) { Text("Pilih klip") }
            Button(onClick = { lutPicker.launch(arrayOf("*/*")) }) { Text("Pilih LUT .cube") }
        }

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
        )

        Text(info?.summary() ?: "Belum ada klip.")
        Text(lutName?.let { "LUT: $it (${lut?.size}³)" } ?: "Belum ada LUT.")

        Text("Intensitas: ${(strength * 100).toInt()}%")
        Slider(
            value = strength,
            onValueChange = { strength = it },
            onValueChangeFinished = { applyEffects() },
            valueRange = 0f..1f,
        )

        message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
