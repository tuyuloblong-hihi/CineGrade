package com.example.cinegrade.gl

import android.graphics.Color
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.SingleColorLut
import com.example.cinegrade.look.CubeLut
import kotlin.math.roundToInt

/**
 * Membuat efek LUT untuk Media3 dari CubeLut.
 * Intensitas dipanggang ke LUT (campuran dengan LUT identitas), jadi shader tetap satu lookup.
 *
 * Catatan fase 1: SingleColorLut memakai 8-bit per kanal. Untuk menghindari banding
 * pada langkah 3, efek ini akan diganti shader sendiri dengan tekstur 3D RGBA16F.
 */
@UnstableApi
fun buildLutEffect(lut: CubeLut, strength: Float): SingleColorLut {
    val n = lut.size
    val k = strength.coerceIn(0f, 1f)
    val last = (n - 1).toFloat()

    fun to8(v: Float) = (v.coerceIn(0f, 1f) * 255f).roundToInt()

    val cube = Array(n) { r ->
        Array(n) { g ->
            IntArray(n) { b ->
                val ident = floatArrayOf(r / last, g / last, b / last)
                val out = IntArray(3) { ch ->
                    val graded = lut.channel(r, g, b, ch)
                    to8(ident[ch] + (graded - ident[ch]) * k)
                }
                Color.rgb(out[0], out[1], out[2])
            }
        }
    }
    return SingleColorLut.createFromCube(cube)
}
