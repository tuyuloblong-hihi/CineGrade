package com.example.cinegrade.look

/**
 * LUT 3D dari file .cube (Adobe/Resolve). Murni Kotlin, tanpa dependensi Android.
 *
 * Tata letak data mengikuti file .cube: merah paling cepat berganti, lalu hijau, lalu biru.
 * Indeks nilai (r, g, b) = ((b * size + g) * size + r) * 3, dengan 3 kanal RGB berurutan.
 * Semua nilai dinormalisasi ke 0..1 memakai DOMAIN_MIN/DOMAIN_MAX.
 */
class CubeLut(val size: Int, val data: FloatArray) {

    init {
        require(size in 2..256) { "Ukuran LUT tidak valid: $size" }
        require(data.size == size * size * size * 3) { "Jumlah data LUT tidak sesuai ukuran" }
    }

    fun channel(r: Int, g: Int, b: Int, ch: Int): Float =
        data[((b * size + g) * size + r) * 3 + ch]

    /** Sampel trilinear pada koordinat 0..1. Hasil ditulis ke out[0..2]. */
    fun sample(r: Float, g: Float, b: Float, out: FloatArray) {
        val n1 = size - 1
        val fr = r.coerceIn(0f, 1f) * n1
        val fg = g.coerceIn(0f, 1f) * n1
        val fb = b.coerceIn(0f, 1f) * n1
        val r0 = fr.toInt().coerceAtMost(n1 - 1)
        val g0 = fg.toInt().coerceAtMost(n1 - 1)
        val b0 = fb.toInt().coerceAtMost(n1 - 1)
        val tr = fr - r0
        val tg = fg - g0
        val tb = fb - b0
        for (ch in 0..2) {
            val c00 = channel(r0, g0, b0, ch) * (1 - tr) + channel(r0 + 1, g0, b0, ch) * tr
            val c10 = channel(r0, g0 + 1, b0, ch) * (1 - tr) + channel(r0 + 1, g0 + 1, b0, ch) * tr
            val c01 = channel(r0, g0, b0 + 1, ch) * (1 - tr) + channel(r0 + 1, g0, b0 + 1, ch) * tr
            val c11 = channel(r0, g0 + 1, b0 + 1, ch) * (1 - tr) + channel(r0 + 1, g0 + 1, b0 + 1, ch) * tr
            val c0 = c00 * (1 - tg) + c10 * tg
            val c1 = c01 * (1 - tg) + c11 * tg
            out[ch] = c0 * (1 - tb) + c1 * tb
        }
    }

    companion object {
        fun parse(text: String): CubeLut {
            var size = 0
            var dMin = floatArrayOf(0f, 0f, 0f)
            var dMax = floatArrayOf(1f, 1f, 1f)
            val values = ArrayList<Float>()

            for (raw in text.lineSequence()) {
                val line = raw.substringBefore('#').trim()
                if (line.isEmpty()) continue
                val parts = line.split(Regex("\\s+"))
                when (parts[0]) {
                    "TITLE", "LUT_3D_INPUT_RANGE" -> Unit
                    "LUT_3D_SIZE" -> size = parts[1].toInt()
                    "LUT_1D_SIZE" -> throw IllegalArgumentException("LUT 1D belum didukung")
                    "DOMAIN_MIN" -> dMin = FloatArray(3) { parts[it + 1].toFloat() }
                    "DOMAIN_MAX" -> dMax = FloatArray(3) { parts[it + 1].toFloat() }
                    else -> {
                        val c = parts[0].first()
                        if (parts.size >= 3 && (c.isDigit() || c == '-' || c == '+' || c == '.')) {
                            for (i in 0..2) values.add(parts[i].toFloat())
                        }
                    }
                }
            }

            require(size >= 2) { "LUT_3D_SIZE tidak ditemukan" }
            require(values.size == size * size * size * 3) {
                "Jumlah baris data (${values.size / 3}) tidak cocok dengan ukuran $size^3"
            }
            val out = FloatArray(values.size)
            for (i in out.indices) {
                val ch = i % 3
                val range = dMax[ch] - dMin[ch]
                out[i] = ((values[i] - dMin[ch]) / (if (range == 0f) 1f else range)).coerceIn(0f, 1f)
            }
            return CubeLut(size, out)
        }
    }
}
