package com.example.cinegrade.shot

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Menganalisis klip: mengambil frame kecil tiap [stepMs], menghitung histogram warna (8x8x8),
 * lalu menyimpan jarak antar-frame berurutan. Pemotongan shot dilakukan terpisah oleh
 * ShotSegmenter, jadi slider ambang bisa mengubah hasil tanpa decode ulang.
 */
object ShotAnalyzer {

    class Result(val times: LongArray, val distances: FloatArray, val durationMs: Long)

    suspend fun analyze(
        context: Context,
        uri: Uri,
        durationMs: Long,
        stepMs: Long = 500,
        onProgress: (Int) -> Unit,
    ): Result = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val timeList = ArrayList<Long>()
            var t = 0L
            while (t < maxOf(durationMs, 1L)) {
                timeList.add(t)
                t += stepMs
            }
            val times = timeList.toLongArray()
            val distances = FloatArray(times.size)
            var prev: FloatArray? = null

            for (i in times.indices) {
                ensureActive()
                val bmp = retriever.getScaledFrameAtTime(
                    times[i] * 1000L,
                    MediaMetadataRetriever.OPTION_CLOSEST,
                    64,
                    36,
                )
                if (bmp != null) {
                    val hist = histogram(bmp)
                    bmp.recycle()
                    val p = prev
                    distances[i] = if (p == null) 0f else l1Half(p, hist)
                    prev = hist
                }
                onProgress(((i + 1) * 100) / times.size)
            }
            Result(times, distances, durationMs)
        } finally {
            retriever.release()
        }
    }

    /** Thumbnail untuk timeline. Mengembalikan null bila frame tidak bisa diambil. */
    suspend fun thumbnail(
        context: Context,
        uri: Uri,
        timeMs: Long,
        width: Int,
        height: Int,
    ): Bitmap? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            retriever.getScaledFrameAtTime(
                timeMs * 1000L,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                width,
                height,
            )
        } catch (e: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    private fun histogram(bmp: Bitmap): FloatArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val hist = FloatArray(512)
        for (p in px) {
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            hist[((r shr 5) shl 6) or ((g shr 5) shl 3) or (b shr 5)] += 1f
        }
        val n = px.size.toFloat()
        for (i in hist.indices) hist[i] /= n
        return hist
    }

    private fun l1Half(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) s += abs(a[i] - b[i])
        return s * 0.5f
    }
}
