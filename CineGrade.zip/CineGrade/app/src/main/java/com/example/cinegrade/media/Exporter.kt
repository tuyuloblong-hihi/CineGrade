package com.example.cinegrade.media

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Ekspor klip dengan efek grading memakai Media3 Transformer.
 * Audio tidak diproses ulang (Transformer meneruskannya bila tidak ada efek audio).
 */
@UnstableApi
object Exporter {

    /** Mengembalikan file sementara di cache. Panggil saveToGallery setelahnya. */
    suspend fun export(
        context: Context,
        source: Uri,
        videoEffect: Effect,
        sourceBitrate: Long?,
        onProgress: (Int) -> Unit,
    ): File = withContext(Dispatchers.Main) {
        val outFile = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        var transformerRef: Transformer? = null
        try {
            coroutineScope {
                val poll = launch {
                    val holder = ProgressHolder()
                    while (isActive) {
                        val t = transformerRef
                        if (t != null && t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                            onProgress(holder.progress)
                        }
                        delay(500)
                    }
                }

                // Bitrate sama dengan sumber (batas 8-60 Mbps), supaya encode ulang tidak menurunkan kualitas.
                val bitrate = (sourceBitrate ?: 20_000_000L).coerceIn(8_000_000L, 60_000_000L).toInt()
                val encoderFactory = DefaultEncoderFactory.Builder(context)
                    .setRequestedVideoEncoderSettings(
                        VideoEncoderSettings.Builder().setBitrate(bitrate).build()
                    )
                    .build()

                suspendCancellableCoroutine<Unit> { cont ->
                    val transformer = Transformer.Builder(context)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setEncoderFactory(encoderFactory)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                if (cont.isActive) cont.resume(Unit)
                            }

                            override fun onError(
                                composition: Composition,
                                exportResult: ExportResult,
                                exportException: ExportException,
                            ) {
                                if (cont.isActive) cont.resumeWithException(exportException)
                            }
                        })
                        .build()
                    transformerRef = transformer

                    val edited = EditedMediaItem.Builder(MediaItem.fromUri(source))
                        .setEffects(Effects(emptyList(), listOf(videoEffect)))
                        .build()
                    transformer.start(edited, outFile.absolutePath)
                }
                poll.cancel()
            }
        } catch (e: CancellationException) {
            transformerRef?.cancel()
            outFile.delete()
            throw e
        } catch (e: Exception) {
            outFile.delete()
            throw e
        }
        outFile
    }

    /** Menyalin file ke galeri (Movies/CineGrade). Tidak butuh izin penyimpanan di Android 10+. */
    fun saveToGallery(context: Context, file: File, displayName: String): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CineGrade")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak bisa membuat entri di galeri")
        try {
            resolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }
}
