package com.example.cinegrade.look

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CubeLutTest {

    private val identity2 = """
        # contoh
        TITLE "identity"
        LUT_3D_SIZE 2
        0 0 0
        1 0 0
        0 1 0
        1 1 0
        0 0 1
        1 0 1
        0 1 1
        1 1 1
    """.trimIndent()

    @Test
    fun parsesIdentityCubeWithRedFastest() {
        val lut = CubeLut.parse(identity2)
        assertEquals(2, lut.size)
        assertEquals(1f, lut.channel(1, 0, 0, 0), 0f)
        assertEquals(0f, lut.channel(1, 0, 0, 1), 0f)
        assertEquals(0f, lut.channel(0, 1, 1, 0), 0f)
        assertEquals(1f, lut.channel(0, 1, 1, 2), 0f)
    }

    @Test
    fun normalizesDomain() {
        val text = identity2.replace("LUT_3D_SIZE 2", "LUT_3D_SIZE 2\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 2 2 2")
        val lut = CubeLut.parse(text)
        assertEquals(0.5f, lut.channel(1, 1, 1, 0), 0f)
    }

    @Test
    fun rejectsWrongRowCount() {
        assertThrows(IllegalArgumentException::class.java) {
            CubeLut.parse("LUT_3D_SIZE 2\n0 0 0\n1 1 1")
        }
    }

    @Test
    fun rejects1dLut() {
        assertThrows(IllegalArgumentException::class.java) {
            CubeLut.parse("LUT_1D_SIZE 4\n0 0 0\n1 1 1")
        }
    }
}
