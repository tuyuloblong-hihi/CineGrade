package com.example.cinegrade.match

import com.example.cinegrade.look.CubeLut
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ClipMatcherTest {

    private fun stats(p50: Float) = ClipStats(
        p5 = p50 - 0.25f, p50 = p50, p95 = p50 + 0.25f,
        meanR = p50, meanG = p50, meanB = p50, meanSat = 0.3f,
    )

    private fun identityCube(n: Int): CubeLut {
        val d = FloatArray(n * n * n * 3)
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) {
            val i = ((b * n + g) * n + r) * 3
            d[i] = r / (n - 1f); d[i + 1] = g / (n - 1f); d[i + 2] = b / (n - 1f)
        }
        return CubeLut(n, d)
    }

    @Test
    fun brighterSourceIsDarkened() {
        val c = ClipMatcher.correction(stats(0.70f), stats(0.45f), 1f)
        assertTrue(c.gain < 1f)
        assertTrue(c.evStops < 0f)
    }

    @Test
    fun darkerSourceIsBrightened() {
        val c = ClipMatcher.correction(stats(0.20f), stats(0.45f), 1f)
        assertTrue(c.gain > 1f)
    }

    @Test
    fun equalStatsGiveIdentity() {
        val s = stats(0.45f)
        val c = ClipMatcher.correction(s, s, 1f)
        val out = FloatArray(3)
        c.apply(0.3f, 0.5f, 0.7f, out)
        assertEquals(0.3f, out[0], 0.01f)
        assertEquals(0.5f, out[1], 0.01f)
        assertEquals(0.7f, out[2], 0.01f)
    }

    @Test
    fun zeroStrengthIsNeutral() {
        val c = ClipMatcher.correction(stats(0.8f), stats(0.2f), 0f)
        assertEquals(1f, c.gain, 1e-5f)
        assertEquals(1f, c.contrast, 1e-5f)
    }

    @Test
    fun exposureIsClampedToOneAndHalfStops() {
        val c = ClipMatcher.correction(stats(0.05f), stats(0.9f), 1f)
        assertTrue(c.evStops <= 1.5f + 1e-3f)
    }

    @Test
    fun correctedMedianMovesTowardTarget() {
        val c = ClipMatcher.correction(stats(0.70f), stats(0.45f), 1f)
        val out = FloatArray(3)
        c.apply(0.70f, 0.70f, 0.70f, out)
        assertEquals(0.45f, out[1], 0.03f)
    }

    @Test
    fun cubeSampleOnIdentityReturnsInput() {
        val lut = identityCube(17)
        val out = FloatArray(3)
        lut.sample(0.123f, 0.456f, 0.789f, out)
        assertEquals(0.123f, out[0], 1e-4f)
        assertEquals(0.456f, out[1], 1e-4f)
        assertEquals(0.789f, out[2], 1e-4f)
    }

    @Test
    fun builderWithoutCorrectionAndCreativeIsIdentity() {
        val lut = ClipLutBuilder.build(null, 1f, null, size = 5)
        assertEquals(0.5f, lut.channel(2, 2, 2, 0), 1e-5f)
        assertEquals(1f, lut.channel(4, 0, 0, 0), 1e-5f)
        assertEquals(0f, lut.channel(4, 0, 0, 1), 1e-5f)
    }

    @Test
    fun builderAppliesCorrection() {
        val c = ClipMatcher.correction(stats(0.70f), stats(0.45f), 1f)
        val lut = ClipLutBuilder.build(null, 1f, c, size = 9)
        // titik tengah abu-abu harus lebih gelap dari aslinya (0.5)
        assertTrue(lut.channel(4, 4, 4, 1) < 0.5f)
    }
}
