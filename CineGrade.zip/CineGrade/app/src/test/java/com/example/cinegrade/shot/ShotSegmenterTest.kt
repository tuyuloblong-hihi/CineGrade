package com.example.cinegrade.shot

import org.junit.Assert.assertEquals
import org.junit.Test

class ShotSegmenterTest {

    private val times = longArrayOf(0, 500, 1000, 1500, 2000, 2500, 3000, 3500)

    @Test
    fun splitsAtSpike() {
        val d = floatArrayOf(0f, 0.05f, 0.04f, 0.05f, 0.7f, 0.05f, 0.04f, 0.03f)
        val shots = ShotSegmenter.segment(times, d, 4000, 0.4f)
        assertEquals(2, shots.size)
        assertEquals(Shot(0, 2000), shots[0])
        assertEquals(Shot(2000, 4000), shots[1])
    }

    @Test
    fun higherThresholdGivesSingleShot() {
        val d = floatArrayOf(0f, 0.05f, 0.04f, 0.05f, 0.7f, 0.05f, 0.04f, 0.03f)
        val shots = ShotSegmenter.segment(times, d, 4000, 0.9f)
        assertEquals(1, shots.size)
        assertEquals(Shot(0, 4000), shots[0])
    }

    @Test
    fun minShotLengthSuppressesRapidCuts() {
        val d = floatArrayOf(0f, 0.6f, 0.6f, 0.05f, 0.05f, 0.05f, 0.05f, 0.05f)
        val shots = ShotSegmenter.segment(times, d, 4000, 0.4f, minShotMs = 800)
        // cut di 500 ditolak (shot awal < 800 ms), cut di 1000 diterima
        assertEquals(2, shots.size)
        assertEquals(1000L, shots[1].startMs)
    }

    @Test
    fun shotsAreContiguousAndCoverClip() {
        val d = floatArrayOf(0f, 0.9f, 0.05f, 0.9f, 0.05f, 0.9f, 0.05f, 0.9f)
        val shots = ShotSegmenter.segment(times, d, 4000, 0.4f, minShotMs = 500)
        assertEquals(0L, shots.first().startMs)
        assertEquals(4000L, shots.last().endMs)
        for (i in 1 until shots.size) assertEquals(shots[i - 1].endMs, shots[i].startMs)
    }
}
